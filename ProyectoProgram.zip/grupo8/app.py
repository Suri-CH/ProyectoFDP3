from flask import Flask, render_template, request,redirect
import pymysql
from datetime import datetime
import psycopg2
from psycopg2 import OperationalError


app = Flask(__name__)
"""  def get_connection():
    return pymysql.connect(
        host='localhost',
        port=3306,
        user='root',
        password='123',
        database='peru',
        cursorclass=pymysql.cursors.DictCursor  # Resultados como diccionarios
    ) """

def get_connection():
    try:
        # Configura tus parámetros de conexión a la base de datos
        connection = psycopg2.connect(
            dbname="playerdb",  # Nombre de tu base de datos
            user="postgres",          # Usuario de la base de datos
            password="postgres",   # Contraseña del usuario
            host="localhost",           # Dirección del servidor (puede ser una IP o nombre del host)
            port="5432"                 # Puerto de PostgreSQL (5432 es el predeterminado)
        )
        return connection
    except OperationalError as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None
    
@app.route('/')
def listar():

    try:
        connection = get_connection()

        # Conectar a la base de datos
        with connection.cursor() as cursor:
            # Ejecutar la consulta
            cursor.execute("SELECT id, taskname,taskduration,taskpriority FROM grupo8")
            datos = cursor.fetchall()  # Obtener todos los resultados
        print('datos=>>>>>>>>>>>>>>>>',datos)
        # Pasar los datos al template
        return render_template("formulario.html", datos=datos)

    except Exception as e:
        return f"Error al conectar a la base de datos: {e}"
    
@app.route('/delete')
def delete():
    try:
        connection =get_connection()
       # id = request.get('id')
        with connection.cursor() as cursor:
            cursor.execute(' delete from grupo8 where id=%s', 2)
        connection.commit()
    except:
        pass
    redirect('/')
    return ''

@app.route('/guardar', methods=['POST'])
def submit():
    task_name = request.form['taskName']
    task_duration = request.form['taskDuration']
    task_priority = request.form['taskPriority']
    fecha = datetime.now().strftime("%Y-%m-%d")  # Solo la fecha sin la hora


    connection = get_connection()
    with connection.cursor() as cursor:
        # Inserta los datos en la tabla grupo8
        cursor.execute("""
            INSERT INTO grupo8 (taskName, taskDuration, taskPriority, fecha)
            VALUES (%s, %s, %s, %s)
        """, (task_name, task_duration, task_priority, fecha))

        # Guardar cambios en la base de datos
        connection.commit()

    connection.close()
    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)