CREATE TABLE grupo8 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    taskName VARCHAR(50),
    taskDuration number,
    taskPriority VARCHAR(15),
    fecha DATE
);